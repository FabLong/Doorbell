# Flash
An Arduino library for smoother, easier access to Flash data.
This fork from MikalHart is the 1.5+ compatible version, and officially added to the Arduino library manager.
